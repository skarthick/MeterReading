/**
 * Created by sunilkarthicksivabalan on 05/06/21.
 */

import React, {Components} from'react';

import {View, Text, FlatList} from 'react-native';


    const meterlist = ({navigation}) => {

        return(
            <View style={{flex:1}}>
    <Text> In Meter List Screen </Text>
        </View>
    );
    };

export default meterlist;