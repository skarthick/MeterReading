/**
 * Created by sunilkarthicksivabalan on 05/06/21.
 */
import React, {Components} from'react';

import {View, Text} from 'react-native';

export default class capturereading extends Components{
    render(){
        return(
            <View style={{flex:1}}>
    <Text> In Reading capture Screen </Text>
        </View>
    );
    }
}